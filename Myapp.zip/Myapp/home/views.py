from django.shortcuts import render,HttpResponse
from datetime import datetime
from django.contrib import messages
from home.models import Contact


# # Create your views here.
# def index(request):
#     context={
#         'variable':"This is sent."
#     }
#     return render(request, 'index.html',context)
#     # return HttpResponse("Hello, World! This is Myapp's index page.")

# def about(request):
#       return render(request, 'about.html')

# def services(request):
#       return render(request, 'services.html')

# def contact(request):
#       if request.method =="POST":
#             name = request.POST['name']
#             email = request.POST['email']
#             subject = request.POST['subject']
#             message = request.POST['message']
#             contact = Contact(name=name, email=email, subject=subject, message=message, date=datetime.now())
#             contact.save()
#             # store data in database
#             # send email
#             messages.success(request, "Your Message has been Sent.")

#       return render(request, 'contact.html')

# def login(request):
#       return render(request, 'login.html')

# def register(request):
#       return render(request, 'register.html')


# views.py
from django.shortcuts import render
from .models import Developer

def home(request):
    developers = Developer.objects.filter(availability_status=True)
    return render(request, 'home.html', {'developers': developers})
