from django.db import models

class Contact(models.Model):
    name = models.CharField(max_length=122)
    email = models.EmailField(max_length=122)
    subject = models.CharField(max_length=50)
    message = models.TextField()
    date = models.DateField() 

def __str__(self):
    return self.name

from django.db import models

class Developer(models.Model):
    name = models.CharField(max_length=100)
    hourly_rate = models.DecimalField(max_digits=10, decimal_places=2)
    availability_status = models.BooleanField(default=True)

class Booking(models.Model):
    developer = models.ForeignKey(Developer, on_delete=models.CASCADE)
    customer_name = models.CharField(max_length=100)
    booking_time = models.DateTimeField(auto_now_add=True)
    payment_status = models.BooleanField(default=False)

