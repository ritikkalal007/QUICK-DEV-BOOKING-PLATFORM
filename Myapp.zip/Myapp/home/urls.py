from django.contrib import admin
from django.urls import path 
from home import views
# urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
]

